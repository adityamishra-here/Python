add = input("Where do you live? ")
print("You are from " + add)